> Formato vigente: suma y resta en decimal con signo (-015..0030); AND y OR en binario de cuatro digitos, bit 3 a la izquierda. BTN3 guarda tanto el resultado como su formato; mover el selector sin ejecutar no cambia lo mostrado.

# Laboratorio 03 — ALU y banco de registros en Zybo Z7-10

Electrónica Digital II · Universidad Nacional de Colombia, sede Bogotá · 2026-2

| Integrante | Correo |
|---|---|
| Julián David Saavedra Pacheco | jusaavedrap@unal.edu.co |
| Juan Sebastián Cortés Gutiérrez | jcortesgu@unal.edu.co |
| Carlos Eduardo Matheus Quintero | cmatheus@unal.edu.co |

Repositorio de destino: [Lab03 del equipo](https://github.com/JulianDSPM-a/Lab03_JulianDavidSaavedraPacheco_JuanSebastianCortesGutierrez_CarlosEduardoMatheusQuintero). La entrega se prepara localmente; la publicación corresponde al equipo. No se han modificado repositorios remotos.

## Estado y alcance

Desarrollo basado en el avance de los compañeros y en la [guía oficial del lab03](https://github.com/jovelasquezs/2026-2_Lab_Electronica_Digital_2_G3yG4/tree/main/labs/lab03), consultada el **25 de octubre de 2026**. Se incluyen la [guía consultada](docs/guia_lab03_original.md), la [matriz de cumplimiento](docs/matriz_cumplimiento.md) y la [explicación de cambios sobre el avance](docs/cambios_sobre_avance.md).

El hardware confirmado es **Zybo Z7-10, xc7z010clg400-1**. El sistema usa los cuatro switches, los cuatro botones, los cuatro LEDs y el RGB LD6 de la placa, más un módulo externo TM1637. La operación se selecciona mediante dos switches externos; no necesita software en el procesador ARM.

**La validación física está pendiente:** el equipo no dispone actualmente del hardware. Las pruebas automáticas, las capturas de GTKWave y los reportes de Vivado se distinguen de una demostración sobre la tarjeta. El procedimiento y el registro de evidencias están preparados en [montaje y prueba](docs/montaje_y_prueba.md) y [registro de hardware](evidencias/hardware/registro.md).

Para el cableado de selección externa y los resultados actuales, consultar [switches externos](docs/switches_externos.md). La guía descargada describe selección compartida; esta revisión aplica el requisito externo indicado explícitamente por el equipo.

## Funcionamiento

Cuatro registros de cuatro bits (R0–R3) almacenan datos introducidos por los switches. BTN0 selecciona el destino de escritura y BTN1 carga el dato. BTN2 recorre pares de registros que alimentan las entradas A y B de la ALU. EXT1:EXT0 elige la operación. Al pulsar BTN3, un registro independiente captura el resultado de la ALU y lo conserva hasta otra ejecución.

La ALU calcula continuamente, pero **el display depende del resultado guardado**, no de su salida instantánea. Por eso cambiar switches, escribir un registro o seleccionar otra pareja no cambia el resultado visible hasta pulsar BTN3. El driver transmite periódicamente los mismos segmentos para mantener el display actualizado eléctricamente; este refresco no implica ejecutar nuevas operaciones.

## Interfaz y operaciones

| Control | Función |
|---|---|
| SW3:SW0 + BTN1 | Dato que se escribe en el registro seleccionado |
| EXT1:EXT0 + BTN3 | Operación que se ejecuta; los switches de la placa solo introducen datos |
| BTN0 | Avanza destino: R0 → R1 → R2 → R3 → R0 |
| BTN1 | Escribe una vez por pulsación en el destino actual |
| BTN2 | Avanza al siguiente par ordenado A,B |
| BTN3 | Captura una vez el resultado actual de la ALU |
| LED0–LED3 | LED3:LED2 indican A; LED1:LED0 indican B (indices binarios) |
| RGB LD6 | Identifica el destino de escritura |
| Display TM1637 | Suma/resta: decimal con signo; AND/OR: cuatro bits binarios |

Los switches de la placa introducen exclusivamente datos. Los dos switches externos seleccionan exclusivamente la operación; ambos buses se sincronizan por separado. BTN1 guarda el dato y BTN3 captura el resultado.

Por indicación del equipo, se utiliza selección externa de operación. Se mantienen las cuatro operaciones mediante dos switches externos. Esta implementación conserva suma, resta, AND y OR del lab02 con dos bits de seleccion:

| EXT1:EXT0 | Operación | Resultado de seis bits con signo | Ejemplo A=5 (`0101`), B=3 (`0011`) |
|---|---|---|---|
| `00` | Suma | `A+B` | `1000` = 8 |
| `01` | Resta | `A−B` | `0010` = 2 |
| `10` | AND | `A & B` | `0001` = 1 |
| `11` | OR | `A \| B` | `0111` = 7 |

Los operandos son enteros sin signo de 0 a 15 (cuatro bits). La ALU y el registro de resultado usan seis bits con signo: sumas de 0 a 30 y restas de -15 a 15, sin recorte modulo 16. AND y OR operan sobre los cuatro bits y producen 0 a 15. El display muestra 15+15 como 0030, 3-5 como -002 y 0-15 como -015. XOR, NOT y desplazamientos se retiraron; JC7 queda libre.

### Destino e indicador RGB

| Destino | Dirección | LD6 | `{R,G,B}` |
|---|---|---|---|
| R0 | `00` | Rojo | `100` |
| R1 | `01` | Verde | `10` |
| R2 | `10` | Azul | `01` |
| R3 | `11` | Blanco | `111` |

El RGB indica **destino de escritura**, no la operación. Los LEDs indican **los indices binarios A y B**, no el resultado numerico. Ambos significados son distintos de los usados en el lab02.

### Recorrido de combinaciones

El índice de cuatro bits comienza en cero, aumenta módulo 16 con BTN2 y se divide en `sel_a=índice[3:2]` y `sel_b=índice[1:0]`.

| Índice | A | B | LED3:LED0 |
|---:|---|---|---|
| 0 | R0 | R0 | `0000` |
| 1 | R0 | R1 | `0001` |
| 2 | R0 | R2 | `0010` |
| 3 | R0 | R3 | `0011` |
| 4 | R1 | R0 | `0100` |
| 5 | R1 | R1 | `0101` |
| 6 | R1 | R2 | `0110` |
| 7 | R1 | R3 | `0111` |
| 8 | R2 | R0 | `1000` |
| 9 | R2 | R1 | `1001` |
| 10 | R2 | R2 | `1010` |
| 11 | R2 | R3 | `1011` |
| 12 | R3 | R0 | `1100` |
| 13 | R3 | R1 | `1101` |
| 14 | R3 | R2 | `1110` |
| 15 | R3 | R3 | `1111` |

Los LEDs codifican el orden A/B: LED3:LED2 indican el indice de A y LED1:LED0 el de B. 0001 significa A=R0, B=R1; 0100 significa A=R1, B=R0. 0000 significa A=B=R0, no ausencia de seleccion.

## Arquitectura modular

```mermaid
flowchart LR
    SW[SW3:SW0] --> SYNC[Sincronizador de switches]
    BTN[BTN0 a BTN3] --> DB[Sincronización y antirrebote]
    DB --> EDGE[Pulso único por botón]
    EDGE -->|BTN0| ADDR[Dirección de escritura]
    EDGE -->|BTN1| BANK[Banco R0 a R3]
    ADDR --> BANK
    SYNC -->|dato de 4 bits| BANK
    EDGE -->|BTN2| COMB[Selector de pares]
    COMB --> BANK
    BANK -->|A y B| ALU[ALU combinacional]
    EXT[Switches externos EXT1:EXT0] --> OPSYNC[Sincronizador de operación]
    OPSYNC --> ALU
    ALU --> REG[Registro del resultado]
    EDGE -->|BTN3| REG
    REG --> FMT[Formato decimal]
    FMT --> TM[Driver TM1637]
    TM --> DISP[Display externo]
    COMB --> LED[LEDs de operandos]
    ADDR --> RGB[RGB de destino]
```

| Archivo | Responsabilidad |
|---|---|
| [top.v](src/top.v) | Conecta módulos, parámetros y recursos físicos. No contiene la tabla de operaciones ni la máquina del display. |
| [alu.v](src/alu.v) | Cálculo combinacional de cuatro operaciones, sin reloj ni habilitación. |
| [reg_bank.v](src/reg_bank.v) | Cuatro registros de cuatro bits, un puerto de escritura síncrono y dos lecturas combinacionales. |
| [address.v](src/address.v) | Contador de dirección de escritura de dos bits. |
| [comb_selector.v](src/comb_selector.v) | Contador de combinaciones de cuatro bits y separación de direcciones A/B. |
| [sync_inputs.v](src/sync_inputs.v) | Dos etapas por switch, con atributos `ASYNC_REG` y `SHREG_EXTRACT`. |
| [debouncer.v](src/debouncer.v) | Sincroniza cada botón y acepta un cambio después de N muestras consecutivas estables. |
| [edge_detector.v](src/edge_detector.v) | Produce una habilitación de un ciclo en el flanco ascendente del nivel filtrado. |
| [result_register.v](src/result_register.v) | Captura el resultado únicamente con el pulso de BTN3. |
| [indicators.v](src/indicators.v) | Decodifica destino en RGB y pareja en LEDs. |
| [display_tm1637.v](src/display_tm1637.v) | Interfaz modular de visualización solicitada: une formato y transmisión. |
| [display_formatter.v](src/display_formatter.v) | Segun el formato guardado, muestra decimal con signo o cuatro bits binarios. |
| [tm1637_driver.v](src/tm1637_driver.v) | Máquina de estados serial con START, bytes LSB primero, ACK y STOP. |

### Almacenamiento, reloj y entradas físicas

Todos los registros usan el reloj de **125 MHz** de la tarjeta. Los botones no son relojes. Las habilitaciones de un ciclo controlan dirección, escritura, combinaciones y ejecución. El antirrebote usa `1.250.000 / 125.000.000 = 10 ms`; filtra tanto presionar como liberar y no repite acciones mientras se mantiene presionado.

Las inicializaciones de los flip-flops establecen R0–R3=0, dirección=0, combinación=0 y resultado=0 al configurar la FPGA. Se aprovecha la inicialización soportada por Xilinx; no se añade un botón de reset porque los cuatro tienen funciones exigidas. Reprogramar el bitstream restaura el estado inicial.

Los switches atraviesan dos etapas de sincronización por bit. Esto reduce el riesgo de metastabilidad, pero no hace atómico un cambio de varios switches: fijar el dato, esperar al menos 30 ms y luego pulsar. Pulsar un botón cada vez es la interfaz prevista. Si varios pulsos se aceptan en el mismo flanco, cada registro usa los valores anteriores a ese flanco: una escritura y una ejecución simultáneas calculan con los operandos anteriores, y un cambio de dirección simultáneo escribe en el destino anterior.

## Estrategia de visualización

Para explicar el protocolo paso a paso, se incluye un [testbench didáctico del TM1637](docs/testbench_tm1637.md), con seis etapas verificadas, VCD y dos sesiones GTKWave (vista general y primer byte ampliado). Ejecutar `scripts/simulate-tm1637-explained.ps1 -Open` desde la raíz de Lab03.

Para suma y resta, el display muestra decimal con signo: positivos 0000..0030 y negativos -001..-015. El signo menos ocupa el primer digito (segmento g, 0x40); los otros tres muestran la magnitud. Los resultados usan seis bits con signo internamente.

El driver captura los cuatro bytes de segmentos juntos al iniciar cada trama. Así evita mezclar bytes de dos resultados si se pulsa BTN3 durante una transmisión. Se envía:

```text
START 40 STOP
START C0 digito3 digito2 digito1 digito0 STOP
START 8F STOP
```

Cada byte sale con el bit menos significativo primero y un noveno pulso para ACK. `40` configura escritura con incremento de dirección, `C0` empieza en GRID1 y `8F` habilita el display al brillo seleccionado. El protocolo de dos hilos del TM1637 no es I²C estándar.

El divisor de cuatro fases es `ceil(125.000.000/(4×100.000))=313`, por lo que el reloj serial es aproximadamente **99,84 kHz**. Cada trama completa tiene 284 ticks, aproximadamente **0,711 ms**; el nuevo dato queda transmitido en menos de dos tramas bajo funcionamiento normal. Esta latencia se añade al antirrebote. El contenido guardado cambia solo con BTN3; la transmisión periódica conserva ese contenido.

DIO se implementa como drenador abierto: cero o alta impedancia. El driver comprueba ACK mediante dos flip-flops y conserva cualquier fallo de la trama en `ack_err`; este diagnóstico no ocupa un LED físico y puede ser eliminado por síntesis al no tener consumidor externo. No se detiene el refresco por falta de ACK, de modo que el siguiente ciclo vuelve a intentarlo.

El [modelo de simulación](sim/tm1637_model.v) observa únicamente CLK/DIO y comprueba comandos, longitudes, orden de bytes y ACK. Sus pull-ups son ideales: **no valida tensiones, cableado, brillo ni características analógicas del módulo real**. Consultar [montaje y alimentación](docs/montaje_y_prueba.md) antes de conectar el display.

## Organización del repositorio

```text
Lab03/
├── README.md
├── src/                    Módulos Verilog de entrega
├── constraints/            Pines de Zybo y restricciones temporales
├── sim/                    Testbenches, modelo TM1637, VCD y sesiones GTKWave
│   └── capturas/            Capturas reales de GTKWave
├── scripts/                Simulación, construcción, programación y verificación
├── bitstreams/             Bitstream para xc7z010clg400-1
├── docs/                   Guía, decisiones, matriz y montaje
├── evidencias/             Resultados de simulación y reportes Vivado
│   └── hardware/           Registro físico pendiente
├── referencia/             Copia intacta del avance recibido
└── build/                  Proyecto Vivado y productos regenerables; ignorados por Git
```

Solo `src/*.v` se sintetiza. No añadir `referencia/` como fuentes: contiene los mismos nombres de módulos de la versión recibida. Los testbenches y el modelo TM1637 pertenecen únicamente a `sim_1`.

## Reproducir simulación y construcción

Requisitos: Icarus Verilog (`iverilog` y `vvp`), GTKWave, Python 3 y Vivado 2025.2 con Zynq-7000. Ejecutar en la raíz de Lab03:

```powershell
.\scripts\simulate.ps1
.\scripts\view-waves.ps1
.\scripts\view-waves.ps1 -Trace tm1637
```

El primer comando compila cada testbench con `iverilog -g2012 -Wall`, ejecuta `vvp`, detiene el proceso ante un fallo y registra los resultados en [evidencias/simulacion.txt](evidencias/simulacion.txt). Genera `sim/alu.vcd`, `sim/top.vcd` y `sim/tm1637.vcd`. Las pruebas unitarias sin VCD utilizan comparaciones automáticas.

`-SkipRealDebounce` sirve para iterar rápidamente, pero no genera una validación completa nueva. La ejecución completa añade el caso de 1.250.000 ciclos y un manifiesto SHA-256 de fuentes, testbenches y restricciones. El script de construcción comprueba que ese manifiesto siga vigente; así no se avanza a FPGA después de una modificación sin simular.

Para construir:

```powershell
.\scripts\build.ps1
```

Si Vivado está en otra ubicación, pasar `-Vivado 'ruta\a\vivado.bat'`. Para este equipo, usar la ruta corta descrita en [reproducción local](docs/reproduccion_local.md), ya que el directorio padre contiene espacios y tildes.

El proyecto regenerado queda en `build/xc7z010clg400-1/lab03.xpr`, con `top` como módulo superior y `tb_top` como simulación principal. La construcción comprueba ausencia de latches, síntesis, implementación, DRC y slack de setup/hold antes de entregar el `.bit`. La programación se explica en [montaje y prueba](docs/montaje_y_prueba.md).

## Verificación y análisis de resultados

| Prueba | Cobertura y resultado esperado |
|---|---|
| [tb_alu.v](sim/tb_alu.v) | 1.024 combinaciones: 4 operaciones × 16 valores de A × 16 de B; comparación contra modelo aritmético. |
| [tb_reg_bank.v](sim/tb_reg_bank.v) | 64 escrituras y 1.040 pares de lectura; aislamiento, retención y escritura solo en flanco. |
| [tb_controls.v](sim/tb_controls.v) | Dirección, dos recorridos de 16 combinaciones, LEDs/RGB y registro de resultado. |
| [tb_debouncer.v](sim/tb_debouncer.v) | N=1, N=4 y N=1.250.000; umbral exacto, rebote, pulsación mantenida y liberación. |
| [tb_display_formatter.v](sim/tb_display_formatter.v) | Los 64 valores de seis bits con signo (-32..31), incluyendo todo el rango de la ALU, signo y cifras decimales. |
| [tb_tm1637.v](sim/tb_tm1637.v) | Siete tramas completas: ACK correcto, NACK temprano, módulo ausente y recuperación; captura coherente durante cambios. |
| [tb_top.v](sim/tb_top.v) | Carga R0–R3, 16 pares × 4 operaciones, retención, pulsación mantenida, cambios de switches y recepción serial. |

En la integración se cargan R0=5, R1=3, R2=10 y R3=15. Para R0,R1 se comprueban los resultados decimales 0008, 0002, 0001 y 0007. Se recorren las 64 combinaciones de pareja y operacion. Para AND/OR los ejemplos son 0001 y 0111. El modelo del display verifica el contenido recibido a través de los pines, no solo el valor de una señal interna.

El testbench integrado usa un reloj de período simulado de 250 ns (4 MHz), reduce el antirrebote a cuatro muestras y mantiene el bus del TM1637 a 100 kHz. **No son los parámetros del bitstream**: la tarjeta usa 125 MHz y 1.250.000 muestras. El antirrebote real se prueba por separado con reloj de 8 ns para no generar millones de transiciones innecesarias en el VCD de integración.

Las trazas VCD del sistema incluyen las señales relevantes y omiten los contadores y el reloj rápido para mantener el archivo legible y pequeño. `stage` identifica las fases de prueba: 0 arranque y ejecución con ceros, 1 carga, 2 operaciones dirigidas, 3 recorrido exhaustivo de parejas, 4 retención tras escritura, 5 BTN3 mantenido, 6 rebotes, 7 independencia de los cuatro switches de datos y 8 eventos simultáneos. La integración supera **197 comprobaciones**. Los detalles se describen en [evidencias de simulación](docs/resultados.md).

### Capturas de GTKWave

Las capturas de operaciones y retención siguientes corresponden a la revisión anterior con selección compartida. Se conservan como referencia histórica; la revisión con switches externos está verificada por el nuevo VCD y el registro de simulación. Abrir `sim/top.vcd` con `sim/top.gtkw` para ver `sw_sel` independiente.

Las capturas reales y su interpretación se incorporan en [resultados y capturas](docs/resultados.md). Los archivos `.gtkw` permiten volver a abrir la misma selección de señales; usar **Zoom Fit** para la vista general y ampliar las transiciones de BTN3 para distinguir cálculo y captura.

![GTKWave: operaciones dirigidas y resultado almacenado](sim/capturas/gtkwave_operaciones.jpg)

Las cuatro operaciones sobre A=5 y B=3 producen los resultados previstos. `alu_out` cambia con el opcode; `result_q` lo captura al ejecutar. `received` permite comparar lo recibido por el modelo del display con el resultado almacenado.

![GTKWave: retención, pulsación mantenida y rebotes](sim/capturas/gtkwave_retencion.jpg)

En las etapas 5 y 6, `alu_out` pasa a `0100` mientras `result_q` conserva `0011`; mantener BTN3 o introducir rebotes breves no causa una segunda ejecución. En la etapa 7, una pulsación válida captura `0100`.

## Implementación en Vivado

La revisión externa fue implementada: **WNS +3,131 ns, WHS +0,122 ns, 0 latches y 0 errores/advertencias críticas DRC**. Usa 106 LUTs y 176 flip-flops. Conserva dos advertencias no bloqueantes explicadas en el informe.

El XDC usa K17 para el reloj de 125 MHz, los pines de switches/botones/LEDs/RGB del XDC maestro de Digilent y **JC1 V15 / JC2 W15** para el display. El periodo de reloj es 8 ns. Las excepciones de entradas humanas terminan en la primera etapa de sincronización; los caminos entre la primera y segunda etapa siguen temporizados.

Los LEDs son salidas de observación humana. CLK/DIO pertenecen a un bus lento generado por habilitaciones de la FSM, no a un dominio de reloj interno adicional. Sus salidas se exceptúan respecto a `sys_clk`; las fases del protocolo se verifican mediante simulación. El análisis temporal interno no sustituye la verificación del montaje externo.

Los resultados de síntesis, implementación y temporización se documentan en [docs/resultados.md](docs/resultados.md) y se conservan en `evidencias/xc7z010clg400-1/`. El bitstream de entrega se encuentra en `bitstreams/lab03_xc7z010clg400-1.bit`.

## Conclusiones

El banco de registros desacopla la introducción de datos de la ejecución; los switches de datos y los de operación son independientes. El registro del resultado separa la actividad continua de la ALU del momento visible de ejecución. La modularidad permite probar por separado almacenamiento, selección, operación y transmisión serial, y después comprobar su interacción.

La validación RTL cubre todos los operandos de la ALU y las combinaciones del sistema. La preparación digital debe complementarse con la prueba física descrita: solo esa prueba confirma que la programación, los niveles eléctricos y el display real funcionan conjuntamente.

## Referencias

- [Guía oficial lab03](https://github.com/jovelasquezs/2026-2_Lab_Electronica_Digital_2_G3yG4/tree/main/labs/lab03).
- [Repositorio de referencia lab02](https://github.com/seb31cortes/Lab02_JulianDavidSaavedraPacheco_JuanSebastianCortesGutierrez_CarlosEduardoMatheusQuintero).
- [XDC maestro Zybo Z7, Digilent](https://github.com/Digilent/digilent-xdc/blob/master/Zybo-Z7-Master.xdc); copia consultada en [docs/](docs/Zybo-Z7-Master.xdc).
- [Manual Zybo Z7, Digilent](https://digilent.com/reference/_media/reference/programmable-logic/zybo-z7/zybo-z7_rm.pdf).
- [TM1637, Titan Micro Electronics, versión 2.4](https://cdn.velleman.eu/downloads/29/infosheets/tm1637_datasheet.pdf).
