# Registro de prueba física — PENDIENTE

No se ha programado ni observado una tarjeta física en esta preparación. El 25 de octubre de 2026 el equipo indicó que no tiene el hardware disponible.

- Fecha/hora de prueba: pendiente
- Responsables presentes: pendiente
- Identificación de placa y dispositivo: pendiente
- Modelo/color/especificación del módulo TM1637: pendiente
- Alimentación del módulo y adaptación de niveles: pendiente
- Bitstream y SHA-256 utilizado: pendiente

| Verificación | Esperado | Observado | Evidencia |
|---|---|---|---|
| Programación JTAG | xc7z010, finalización correcta | Pendiente | Pendiente |
| Arranque | R0–R3=0, RGB rojo, LED0, display 0000 | Pendiente | Pendiente |
| Escritura independiente | Solo cambia el registro destino al pulsar BTN1 | Pendiente | Pendiente |
| Selección destino | R0 rojo → R1 verde → R2 azul → R3 blanco → R0 | Pendiente | Pendiente |
| Combinaciones | 16 pares ordenados y retorno al inicio | Pendiente | Pendiente |
| Suma 5+3 | 1000 | Pendiente | Pendiente |
| Resta 5−3 | 0010 | Pendiente | Pendiente |
| AND 5&3 | 0001 | Pendiente | Pendiente |
| OR 5\|3 | 0111 | Pendiente | Pendiente |
| XOR 5^3 | 0110 | Pendiente | Pendiente |
| NOT 5 | 1010 | Pendiente | Pendiente |
| 5 << 1 | 1010 | Pendiente | Pendiente |
| 5 >> 1 | 0010 | Pendiente | Pendiente |
| Retención al cambiar operación | Display conserva último resultado | Pendiente | Pendiente |
| Retención al escribir operando | Display conserva último resultado | Pendiente | Pendiente |
| Retención al cambiar pareja | Display conserva último resultado | Pendiente | Pendiente |
| BTN3 mantenido | No ejecuta repetidamente | Pendiente | Pendiente |
| Overflow 9+10 | 0011 | Pendiente | Pendiente |
| Resta negativa 3−5 | 1110 | Pendiente | Pendiente |

Resultado final y observaciones: **pendiente**.
