`timescale 1ns/1ps
module tb_tm1637;
    // 4 MHz reales en esta simulacion, serial 100 kHz (DIV=10).
    reg clk=0;always #125 clk=~clk;
    reg [31:0] segments=32'h063f063f;
    reg ack=1;
    wire tm_clk,tm_dio,ack_err;
    wire [31:0] received,frames;
    tm1637_driver #(.CLK_HZ(4_000_000)) dut(clk,segments,tm_clk,tm_dio,ack_err);
    tm1637_model model(tm_clk,tm_dio,ack,received,frames);
    task next_frame;
        reg [31:0] n;
        begin n=frames;wait(frames>n);#1000;end
    endtask
    initial begin
        $dumpfile("sim/tm1637.vcd");
        $dumpvars(0,segments,ack,tm_clk,tm_dio,ack_err,received,frames);
        next_frame;
        if(received!==segments || ack_err!==0) $fatal(1,"Trama inicial o ACK");
        // Cambiar datos DURANTE la trama: los cuatro bytes siguen siendo coherentes.
        wait(dut.state==2 && dut.idx==2);segments=32'h3f063f06;
        next_frame;
        if(received!==32'h063f063f) $fatal(1,"Trama mezclada");
        next_frame;
        if(received!==segments) $fatal(1,"Nueva trama no actualizada");
        // Un NACK temprano no debe desaparecer con los ACK posteriores.
        wait(dut.state==1 && dut.idx==0);ack=0;
        wait(dut.state==4 && dut.idx==0);ack=1;
        next_frame;
        if(ack_err!==1) $fatal(1,"NACK temprano no retenido en trama");
        next_frame;
        if(ack_err!==0) $fatal(1,"Recuperacion ACK");
        ack=0;next_frame;
        if(ack_err!==1) $fatal(1,"Display ausente no detectado");
        ack=1;next_frame;
        if(ack_err!==0 || received!==segments) $fatal(1,"Recuperacion final");
        $display("PASS TM1637: %0d tramas, comandos, LSB, ACK/NACK, coherencia y recuperacion",frames);
        $finish;
    end
    initial begin #20_000_000;$fatal(1,"Timeout TM1637");end
endmodule
