`timescale 1ns/1ps
// Receptor conductual independiente del driver: observa SOLO CLK/DIO.
// Modela pull-up ideal, ACK, bytes LSB primero y comandos usados por el diseno.
// No modela brillo optico, RC, niveles electricos ni metastabilidad.
module tm1637_model(input wire tm_clk, inout wire tm_dio,
    input wire ack_enable, output reg [31:0] received_segments=0,
    output reg [31:0] frames=0);
    reg ack_low=0,active=0;
    reg [7:0] byte_value=0;
    reg [7:0] bytes[0:7];
    integer bits=0,count=0;
    reg got_mode=0,got_data=0;
    assign tm_dio=ack_low ? 1'b0 : 1'bz;
    pullup(tm_dio);
    always @(negedge tm_dio) if(tm_clk===1'b1) begin
        if(active) $fatal(1,"START inesperado dentro de transaccion");
        active=1;bits=0;count=0;byte_value=0;
    end
    always @(posedge tm_clk) if(active) begin
        if(tm_dio!==1'b0 && tm_dio!==1'b1) $fatal(1,"DIO indefinido/contencion");
        if(bits<8) byte_value[bits]=tm_dio;
        else if(bits==8) begin
            if(count>=7) $fatal(1,"Demasiados bytes");
            bytes[count]=byte_value;count=count+1;
            if(tm_dio!==!ack_enable) $fatal(1,"Slot ACK incorrecto");
        end else $fatal(1,"Relojes extra");
        bits=bits+1;
    end
    always @(negedge tm_clk) if(active) begin
        if(bits==8) ack_low=ack_enable;
        else if(bits==9) begin ack_low=0;bits=0;byte_value=0;end
    end
    always @(posedge tm_dio) if(tm_clk===1'b1 && active) begin
        active=0;
        case(bytes[0])
            8'h40: begin
                if(count!=1) $fatal(1,"Longitud comando modo");
                got_mode=1;
            end
            8'hc0: begin
                if(count!=5 || !got_mode) $fatal(1,"Direccion/datos/orden incorrectos");
                received_segments={bytes[1],bytes[2],bytes[3],bytes[4]};
                got_data=1;
            end
            8'h8f: begin
                if(count!=1 || !got_mode || !got_data) $fatal(1,"Control brillo/orden");
                frames=frames+1;got_mode=0;got_data=0;
            end
            default: $fatal(1,"Comando TM1637 inesperado: %h",bytes[0]);
        endcase
    end
endmodule
