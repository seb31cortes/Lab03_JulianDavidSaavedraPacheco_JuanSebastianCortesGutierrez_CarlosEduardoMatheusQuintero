`timescale 1ns/1ps
// Demostracion del protocolo. Ejecutar desde la raiz de Lab03.
module tb_tm1637_explicado;
    // 4 MHz para simular; bus serial 100 kHz. Hardware: 125 MHz.
    reg clk=0;
    always #125 clk=~clk;
    reg signed [5:0] resultado=0;
    reg ack_enable=1;
    reg [7:0] etapa=0;
    wire [31:0] segmentos,recibido,tramas;
    wire tm_clk,tm_dio,ack_err;
    display_formatter formato(resultado,segmentos,1'b0);
    tm1637_driver #(.CLK_HZ(4_000_000),.BIT_HZ(100_000)) dut(
        .clk(clk),.segments(segmentos),.tm_clk(tm_clk),
        .tm_dio(tm_dio),.ack_err(ack_err));
    // El modelo aporta pull-up ideal y responde ACK bajando DIO.
    tm1637_model pantalla(tm_clk,tm_dio,ack_enable,recibido,tramas);

    task esperar_trama;
        reg [31:0] anterior;
        begin anterior=tramas;wait(tramas>anterior);#1000;end
    endtask
    task comprobar(input [31:0] dato,input error_esperado);
        begin
            if(recibido!==dato || ack_err!==error_esperado)
                $fatal(1,"Etapa %0d: recibido=%h ACK_ERR=%b",etapa,recibido,ack_err);
            $display("ETAPA %0d OK: trama=%0d segmentos=%h ack_err=%b",etapa,tramas,recibido,ack_err);
        end
    endtask
    // Monitor del receptor: termina de reconstruir cada byte en el noveno pulso.
    always @(posedge tm_clk) begin
        #1;
        if(pantalla.active && pantalla.bits==9)
            $display("t=%0t ns BYTE=%h ACK=%b (0=aceptado)",
                     $time,pantalla.bytes[pantalla.count-1],tm_dio);
    end
    initial begin
        $timeformat(-9,0,"",12);
        $dumpfile("sim/didactico/tm1637_explicado.vcd");
        // Omitir reloj rapido: conservar las senales que explican la FSM y el bus.
        $dumpvars(0,etapa,resultado,segmentos,recibido,tramas,ack_enable,
            tm_clk,tm_dio,ack_err,dut.state,dut.ph,dut.idx,dut.bit_i,
            dut.cur_byte,dut.seg_q,dut.dio_low,dut.frame_error,pantalla.ack_low);
        etapa=1; // Trama inicial: 0000 -> 3F 3F 3F 3F.
        esperar_trama;comprobar(32'h3f3f3f3f,0);
        etapa=2; // Cambiar a mitad de datos: no mezclar dos resultados.
        wait(dut.state==2 && dut.idx==2);
        @(negedge clk);resultado=4'b1010;
        esperar_trama;comprobar(32'h3f3f3f3f,0);
        etapa=3; // La siguiente trama transmite decimal 0010 -> 3F 3F 06 3F.
        esperar_trama;comprobar(32'h3f3f063f,0);
        etapa=4; // Mantener dato: sigue el refresco, no cambia el contenido.
        esperar_trama;comprobar(32'h3f3f063f,0);
        etapa=5; // Retirar ACK un ciclo completo: se detecta al final de la trama.
        ack_enable=0;
        esperar_trama;comprobar(32'h3f3f063f,1);
        etapa=6; // Restablecer respuesta y transmitir 0101.
        ack_enable=1;resultado=4'b0101;
        esperar_trama;comprobar(32'h3f3f3f6d,0);
        $display("PASS DIDACTICO TM1637: 6 tramas, retencion de trama, refresco, NACK y recuperacion");
        $finish;
    end
    initial begin #10_000_000;$fatal(1,"Timeout didactico");end
endmodule
